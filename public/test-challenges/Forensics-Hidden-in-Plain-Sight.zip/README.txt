Forensics - Hidden in Plain Sight

Provided file:
  - office_photo.jpg

Note for organizers:
  - The flag is embedded in the JPEG COM (comment) segment.
  - Tools like 'exiftool' and sometimes 'strings' can reveal it.
